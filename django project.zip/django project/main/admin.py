from django.contrib import admin

# Register your models here.
from main.models import login
admin.site.register(login)
from main.models import registration
admin.site.register(registration)

