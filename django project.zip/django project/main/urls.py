from django.urls import include, path
from . import views
urlpatterns = [
   path('home',views.home),
   path('aboutus',views.aboutus),
   path('contacts',views.contacts),
   path('login',views.login),
   path('registration',views.registration),
]

