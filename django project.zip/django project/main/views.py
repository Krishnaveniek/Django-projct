from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'home.html')
def aboutus(request):
    return render(request,'aboutus.html')
def contacts(request):
    return render(request,'contacts.html')
def login(request):
    if request.method=="POST":
        un=request.POST['fname']
        pwd=request.POST['lname']
        print("username=",un)
        print("password=",pwd)
    return render(request,'login.html')
def registration(request):
    if request.method=="POST":
        u=request.POST['firstname']
        v=request.POST['middlename']
        w=request.POST['lastname']
        x=request.POST['cource']
        a=request.POST['gender']
        b=request.POST['phone']
        c=request.POST['current address']
        print("firstname=",u,"\n")
        print("middlename=",v)
        print("lastname=",w)
        print("cource=",x)
        print("gender=",a)
        print("phone=",b)
        print("current address=",c)
    return render(request,'registration.html')




